
import 'package:flutter/foundation.dart';

class Category{
  String categoryName;
  String imageUrl;
  Category({this.categoryName,this.imageUrl});
}